---
id: multi-level-menu
title: Multi-level Menu
example-tags: [antd,customization,refine-hooks]
---

The multi-level menu will provide you with the necessary infrastructure to create your resources with the priority.

<CodeSandboxExample path="multi-level-menu" />