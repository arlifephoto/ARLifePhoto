---
id: offLayoutArea
title: Off Layout Area
example-title: Custom Off Layout Area
example-tags: [antd,customization]
---

With **refine**, you may manage your entire project. It does not limit you in any way, giving you complete creative control. This example shows how to customize and employ **refine**`s Off Layout Area in detail.

<CodeSandboxExample path="customization-offlayout-area" />
