---
id: rtl
title: RTL (Right to Left)
example-title: RTL Layout
example-tags: [antd,customization]
---

This example shows how to use **refine** to manage and customize the content of your Layout. You may adapt and design your Layout content as you choose by examine this example and the source code.

<CodeSandboxExample path="customization-rtl" />
