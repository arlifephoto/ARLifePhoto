---
id: customSider
title: Custom Sider
example-title: Custom Sider
example-tags: [antd,customization]
---

Creating your own `Sider Menu` with **refine** is quite simple. We have customize the default **refine** Sider Menu in this example. You can customize the sider menu of your **refine** project based examine this sample.

<CodeSandboxExample path="customization-sider" />
