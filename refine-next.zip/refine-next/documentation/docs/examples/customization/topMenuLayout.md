---
id: topMenuLayout
title: Top Menu Layout
example-title: Top Menu Layout
example-tags: [antd,customization]
---

**refine** enables you to customize and organize your UI as you choose thanks to its strong customization capabilities. It is shown in this case how to modify the custom `Top Menu Layout` component.

<CodeSandboxExample path="customization-top-menu-layout" />
