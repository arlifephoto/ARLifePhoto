---
id: customPages
title: Custom Pages
example-title: Custom Pages with Ant Design
example-tags: [antd,customization]
---

The feature to modify your project in detail is a major benefit of using **refine**. In this example, you learn how to include and manage your own [Pages / Routes](/docs/packages/documentation/routers/) in your project.

<CodeSandboxExample path="with-custom-pages" />
