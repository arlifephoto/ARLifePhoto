---
id: javascript
title: JavaScript
example-title: Refine with Javascript
example-tags: [javascript,antd]
---

Refine supports you to develop with JavaScript. All features of **refine** can be used with JavaScript. In our example below, we developed the [tutorial](/docs/tutorial/introduction/index/) with Antd Design selection entirely with JavaScript. You can learn more by following the live example.

<CodeSandboxExample path="with-javascript" />
