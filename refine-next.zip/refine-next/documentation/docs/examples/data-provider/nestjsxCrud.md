---
id: nestjsxCrud
title: Nestjsx Crud
example-tags: [antd,data-provider,nestJsx-crud]
---

**refine** [Nestjsx Crud](https://github.com/nestjsx/crud) Data Provider allows you to use your data on the frontend by connecting to your Nestjsx API. With **refine**, it perform these operations for you without having to write extra code for queries. By examining this example, you can learn how to use the Nestjsx Crud Data Provider.

<CodeSandboxExample path="data-provider-nestjsx-crud" />
