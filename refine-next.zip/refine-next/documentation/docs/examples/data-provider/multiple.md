---
id: multiple
title: Multiple Providers
example-tags: [antd,data-provider]
---

**refine**'s Multiple Data Provider feature allows you to connect multiple backends and manage their data with a single interface. This tutorial explains in detail how to use the Multiple Data Provider in your project.

<CodeSandboxExample path="data-provider-multiple" />
