---
id: airtable
title: Airtable
example-tags: [antd,data-provider,airtable]
---

By using **refine**`s full-featured [Airtable](https://www.airtable.com/) Data Provider, it allows you to access your data quickly without any additional setup or coding. The following example will show you how to use your Airtable data within the **refine** project.

<CodeSandboxExample path="data-provider-airtable" />
