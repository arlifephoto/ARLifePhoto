---
id: ably
title: Ably
example-tags: [antd,live-provider,ably,data-provider]
---

The [liveProvider](/docs/advanced-tutorials/real-time/) is a powerful tool for developers who want to create an interactive app experience that can be updated in Realtime. This is an example of **refine** that you can use to manage your data in Realtime.

<CodeSandboxExample path="live-provider-ably" />
