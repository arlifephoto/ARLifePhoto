---
slug: ant-design-calendar-example
id: antd-calendar-example
title: Calendar
example-tags: [antd]
---

In this example you can see how Ant Design's [Calendar](https://ant.design/components/calendar) component can be used with Refine data hooks.

<CodeSandboxExample path="calendar-app" />